
let cart = [];
function addToCart(name, price) {
  cart.push({ name, price });
  displayCart();
}
function displayCart() {
  const cartList = document.getElementById("cart-items");
  const totalTag = document.getElementById("total");
  cartList.innerHTML = "";
  let total = 0;
  cart.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item.name + " - ₹" + item.price;
    cartList.appendChild(li);
    total += item.price;
  });
  totalTag.textContent = "Total: ₹" + total;
}
